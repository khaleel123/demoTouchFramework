//
//  demoTouchFramework.h
//  demoTouchFramework
//
//  Created by YuppTV on 08/01/19.
//  Copyright © 2019 YuppTV. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for demoTouchFramework.
FOUNDATION_EXPORT double demoTouchFrameworkVersionNumber;

//! Project version string for demoTouchFramework.
FOUNDATION_EXPORT const unsigned char demoTouchFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <demoTouchFramework/PublicHeader.h>


